getwd()
setwd("C:\\Users\\IT24100701\\Desktop\\IT24100701")
branch_data<-read.csv("Exercise.txt")
fix(branch_data)
attach(branch_data)
boxplot(Sales_X1,main="sales",outline=TRUE)
summary(Advertising_X2)
IQR(Advertising_X2)
get.outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  
  print(paste("upper bound = ", ub))
  print(paste("lower bound = ", lb))
  print(paste("outliers = ", paste(sort(z[z<lb | z>ub]),collapse = ",")))
}
get.outliers(Years_X3)