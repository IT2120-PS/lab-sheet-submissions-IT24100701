getwd()
setwd("C:\\Users\\IT24100701\\Desktop\\IT24100701")
data<-read.csv("DATA 4.txt",header=TRUE,sep=" ")
fix(data)
attach(data)
boxplot(X1,main="attendance")
boxplot(X2,main="salary")
boxplot(X3,main="years")
hist(X1,xlab="frequency",ylab="attendance",main="attendance histogram")

hist(X2,xlab="frequency",ylab="salary",main="slaray histogram")

hist(X3,xlab="frequency",ylab="years",main="years histogram")

stem(X1)
stem(X2)
stem(X3)

mean(X1)
mean(X2)
mean(X3)

median(X1)
median(X2)
median(X3)

sd(X1)
sd(X2)
sd(X3)

summary(X1)
summary(X2)
summary(X3)

IQR(X1)
IQR(X2)
IQR(X3)

get.mode<-function(z){
  counts<-table(z)
  names(counts[counts==max(counts)])
}

get.mode(X3)


get.outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  
  print(paste("upper bound = ", ub))
  print(paste("lower bound = ", lb))
  print(paste("outliers = ", paste(sort(z[z<lb | z>ub]),collapse = ",")))
}

get.outliers(X1)
get.outliers(X2)
get.outliers(X3)